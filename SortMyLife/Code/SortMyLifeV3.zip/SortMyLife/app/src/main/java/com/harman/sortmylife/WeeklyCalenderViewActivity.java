package com.harman.sortmylife;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class WeeklyCalenderViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weekly_calender_view);
    }
}