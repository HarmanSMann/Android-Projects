package com.harman.sortmylife;

/*
<!--
budget expanded
Created By:
Sujitha Bayya - N01472369
-->
*/

import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity2 extends AppCompatActivity {
    List<String> groupList;
    List<String> childList;
    Map<String, List<String>> budgetCollection;
    ExpandableListView expandableListView;
    ExpandableListAdapter expandableListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        createGroupList();
        createCollection();
        expandableListView = findViewById(R.id.b_listview);
        expandableListAdapter = new MyExpandableListAdapter(this, groupList, budgetCollection);
        expandableListView.setAdapter(expandableListAdapter);
        expandableListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            int lastExpandedPosition = -1;
            @Override
            public void onGroupExpand(int i) {
                if(lastExpandedPosition != -1 && i != lastExpandedPosition){
                    expandableListView.collapseGroup(lastExpandedPosition);
                }
                lastExpandedPosition = i;
            }
        });
        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView expandableListView, View view, int i, int i1, long l) {
                String selected = expandableListAdapter.getChild(i,i1).toString();
                Toast.makeText(getApplicationContext(), "Selected: " + selected, Toast.LENGTH_SHORT).show();
                return true;
            }
        });
    }

    private void createCollection() {
        String[] monthlyBudget = {"Monthly 1", "Monthly 2"};
        String[] weeklyBudget = {"Weekly 1","Weekly 2","Weekly 3"};
        String[] dailyBudget = {"Daily 1"};

        budgetCollection = new HashMap<String, List<String>>();
        for(String group : groupList){
            if (group.equals("Monthly")){
                loadChild(monthlyBudget);
            } else if (group.equals("Weekly"))
                loadChild(weeklyBudget);
            else if (group.equals("Daily"))
                loadChild(dailyBudget);
            budgetCollection.put(group, childList);
        }
    }

    private void loadChild(String[] expenseItems) {
        childList = new ArrayList<>();
        for(String expense : expenseItems){
            childList.add(expense);
        }
    }

    private void createGroupList() {
        groupList = new ArrayList<>();
        groupList.add("Monthly");
        groupList.add("Weekly");
        groupList.add("Daily");

    }
}