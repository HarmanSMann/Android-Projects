package com.harman.sortmylife;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class BudgetExpandedActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_budget_expanded);
    }
}